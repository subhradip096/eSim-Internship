mips_16_assembler.java :
	Java implementation of the assembler, source code.
	Java version: 1.6.0_30.

mips_16_assembler.class
	executable Java class file.
	Useage:
	java mips_16_assembler [Options]
	Options:
		<source_code_path> <dest_path>:
	Assemble source code to dest. For exaple .\bin\test1.asm .\bin\test1.prog
	<source_code_path>:
	Assemble source code to dest file a.prog
	-h(or --help):
	Show this help
